#include "../includes/header_commun.h"
#include "../includes/network.h"

static void exchange(SOCKET s);

#define SVR_PORT 1234

/* Conversion string→long */
long stringToLong(const char *str) {
    return strtol(str, NULL, 10);
}

/* Échange avec le client */
void exchange(SOCKET s) {
    char toReceive[16];
    int len = TCP_String_Reader(s, toReceive);
    printf("Server received : %s\n", toReceive);

    // Vérification si le message est correct (format A1..I9)
    if (len != 4 ||
        toReceive[0] < 'A' || toReceive[0] > 'I' ||
        toReceive[1] < '1' || toReceive[1] > '9' ||
        toReceive[2] < 'A' || toReceive[2] > 'I' ||
        toReceive[3] < '1' || toReceive[3] > '9') {

        const char *errMsg = "Erreur : coup invalide !";
        TCP_String_Writer(s, errMsg);
        printf("Server sent error: %s\n", errMsg);
        shutdown(s, SHUT_WR); // coupe la communication
        return;
    }

    // 4 caractères + saut de ligne éventuel + '\0'
    char response[8];  

    printf("Entrez un coup d'échec (ex: I9I1) : ");
    if (fgets(response, sizeof(response), stdin) == NULL) {
        perror("fgets");
        shutdown(s, SHUT_RDWR);
        return;
    }

    // Supprimer le '\n' éventuel en fin de chaîne
    response[strcspn(response, "\n")] = '\0';

    // Envoyer au client
    TCP_String_Writer(s, response);
    printf("Server sent     : %s\n", response);

    shutdown(s, SHUT_WR);

}

int run_server(short port) {
    SOCKET master = TCP_Create_Server(port);
    if (master == INVALID_SOCKET) {
        fprintf(stderr, "Erreur création serveur\n");
        return 1;
    }

    printf("Server started on port %d, listening...\n", port);

    while (1) {
        SOCKET slave = accept(master, NULL, NULL);
        if (slave == INVALID_SOCKET) {
            perror("accept");
            continue;
        }

        printf("Client connected: socket %d\n", slave);
        exchange(slave);
        shutdown(slave, SHUT_RDWR);
        printf("Connection %d closed\n", slave);
    }

    shutdown(master, SHUT_RDWR);
    return 0;
}   
