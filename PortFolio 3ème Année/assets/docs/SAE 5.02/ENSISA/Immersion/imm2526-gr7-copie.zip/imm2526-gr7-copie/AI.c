#include <stdlib.h>  // pour rand()
#include <time.h>    // pour srand()
#include "app.h"     // le fichier avec les définitions

// Structure pour stocker un coup possible
typedef struct {
    int from_r, from_c; // position de départ
    int to_r, to_c;     // position d'arrivée
} Move;

// Fonction pour générer l'IA Random
void IA_random(Player pl) {
    // Initialisation de la liste de coups valides
    Move moves[1000]; // taille arbitraire, on suppose pas plus de 1000 coups
    int move_count = 0;

    // Initialisation du générateur aléatoire
    srand(time(NULL));

    // Parcours de tout le plateau
    for(int r=0; r<N; r++){
        for(int c=0; c<N; c++){
            Piece p = board[r][c];

            // On ne considère que les pièces alliées du joueur
            if(!is_ally(p, pl)) continue;

            // Parcours des directions verticales et horizontales
            int dr[4] = {-1, 1, 0, 0}; // haut, bas, gauche, droite
            int dc[4] = {0, 0, -1, 1};

            for(int d=0; d<4; d++){
                int r1 = r + dr[d];
                int c1 = c + dc[d];

                // Avancer dans cette direction jusqu'au bord ou blocage
                while(in_bounds(r1,c1) && board[r1][c1]==EMPTY){
                    // Vérifier que le chemin est libre
                    if(!path_clear(r,c,r1,c1)) break;

                    // Ajouter ce coup valide à la liste
                    moves[move_count].from_r = r;
                    moves[move_count].from_c = c;
                    moves[move_count].to_r = r1;
                    moves[move_count].to_c = c1;
                    move_count++;

                    // Continuer dans la même direction
                    r1 += dr[d];
                    c1 += dc[d];
                }
            }
        }
    }

    // Si on a au moins un coup valide
    if(move_count > 0){
        int choice = rand() % move_count; // choisir un coup aléatoire
        Move m = moves[choice];

        // Exécuter le coup choisi
        try_move(m.from_r, m.from_c, m.to_r, m.to_c);
    }
}
