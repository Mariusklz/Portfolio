#ifndef APP_H
#define APP_H

#include <gtk/gtk.h>
#include <stdbool.h>
#include "app.h"

#define N 9
#define MAX_TURNS 64


// Lance le mode local (GUI seule)
int app_run_local(void);

typedef enum {
    EMPTY = 0,
    BLUE_SOLDIER,
    BLUE_KING,
    RED_SOLDIER,
    RED_KING,
    CITY
} Piece;

typedef enum {
    CTRL_NEUTRAL = 0,
    CTRL_BLUE = 1,
    CTRL_RED = 2
} Control;

typedef enum {
    BLUE = 0,
    RED = 1
} Player;

// ---- Variables globales du jeu (définies dans app.c, utilisées dans gui.c) ----
extern Piece board[N][N];
extern Control control_grid[N][N];
extern Player current_player;
extern int turn_count;

extern int captured_blue_soldiers;
extern int captured_red_soldiers;
extern gboolean blue_king_alive;
extern gboolean red_king_alive;

extern gboolean has_selection;
extern int sel_r, sel_c;
extern int hover_r, hover_c;

// ---- Fonctions exportées ----
void new_game_setup(void);
gboolean try_move(int r0, int c0, int r1, int c1);
void check_end_and_update(GtkWidget *status_label, GtkWidget *drawing_area);
void update_labels(GtkWidget *blue_status_label, GtkWidget *blue_score_label, GtkWidget *blue_turn_label,
                   GtkWidget *red_status_label, GtkWidget *red_score_label, GtkWidget *red_turn_label);





#endif
