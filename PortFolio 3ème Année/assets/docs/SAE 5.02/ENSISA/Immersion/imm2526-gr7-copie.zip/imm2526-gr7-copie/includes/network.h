#ifndef NET_H
#define NET_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <stdint.h>
#include <gtk/gtk.h>
#include <math.h>
#include <cairo.h>
#include <cairo.h>
#include <unistd.h>         // close(), shutdown()

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>     // struct sockaddr_in, htons()
#include <netdb.h>          // getprotobyname()
#include <arpa/inet.h>      // htonl(), ntohl()


// Définition du type SOCKET et des constantes d’erreur
typedef int SOCKET;
#define INVALID_SOCKET  (-1)
#define SOCKET_ERROR    (-1)

// Variables globales pour l'état réseau
extern int network_socket;
extern int is_server;
extern int is_connected;

// -- Serveur TCP ---------------------------------

int run_server(short port);
int run_client(const char *ip, short port);

// Nouvelles fonctions pour intégration GUI
int network_init_server(short port);
int network_init_client(const char *ip, short port);
int network_send_move_async(int from_r, int from_c, int to_r, int to_c);
int network_check_move(int *from_r, int *from_c, int *to_r, int *to_c);
void network_cleanup();


SOCKET  TCP_Create_Server(short port);
void    server_exchange(SOCKET s);
int     TCP_String_Reader(int sock, char *buffer);
int     TCP_Long_Writer(SOCKET s, long value);

// -- Client TCP ------------------------
// // Démarre le mode client (connexion + GUI)
int client_run(const char *host, short port);
SOCKET  TCP_Create_Client(const char *server_ip, short port);
int     TCP_String_Writer(SOCKET s, const char *output);
int     TCP_Long_Reader(SOCKET s, long *value);

#endif