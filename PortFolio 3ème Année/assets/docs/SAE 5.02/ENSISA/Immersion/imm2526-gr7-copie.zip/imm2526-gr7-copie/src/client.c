#include "../includes/header_commun.h"
#include "../includes/network.h"

static void exchange(SOCKET s);

#define SVR_IP "127.0.0.1"
#define SVR_PORT 1234

int run_client(const char *ip, short port) {
    SOCKET s = TCP_Create_Client(ip, port);
    if (s == INVALID_SOCKET) {
        fprintf(stderr, "Erreur connexion client\n");
        return 1; // code erreur
    }

    exchange(s);

    shutdown(s, SHUT_RDWR);
    close(s);

    return 0; // code succès
}

static void exchange(SOCKET s) {
    if (s == INVALID_SOCKET) exit(1);

    char toSend[8]; // 4 caractères + marge + '\0'
    printf("Entrez un coup d'échec (ex: A1A8) : ");
    if (fgets(toSend, sizeof(toSend), stdin) == NULL) {
        perror("fgets");
        close(s);
        exit(1);
    }

    // Supprimer le retour à la ligne éventuel
    toSend[strcspn(toSend, "\n")] = '\0';

    // Vérifier que la longueur est bien de 4 caractères
    if (strlen(toSend) != 4) {
        fprintf(stderr, "Erreur : le coup doit contenir exactement 4 caractères (ex: A1A8).\n");
        close(s);
        return;
    }

    TCP_String_Writer(s, toSend);
    printf("Client sent : %s\n", toSend);

    shutdown(s, 1); // fin d’envoi

    char buffer[256] = {0};
    int bytes_received = recv(s, buffer, sizeof(buffer) - 1, 0);
    if (bytes_received > 0) {
        buffer[bytes_received] = '\0';
        printf("Client received : %s\n", buffer);
    } else {
        printf("Aucune réponse reçue.\n");
    }

    shutdown(s, 0);
    close(s);
}


