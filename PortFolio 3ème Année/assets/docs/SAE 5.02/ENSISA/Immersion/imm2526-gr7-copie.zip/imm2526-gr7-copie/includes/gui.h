#ifndef GUI_H
#define GUI_H

#include <gtk/gtk.h>

void gui_activate(GtkApplication *app, gpointer user_data);

#endif
