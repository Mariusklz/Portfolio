#include "ai.h"
#include "app.h"
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <gtk/gtk.h>
#include <time.h>
#include <stdlib.h>

//Variable(s) globale(s)
Position ai_pieces_jouables[20] ;
Position ai_posi_jouables[N*N] ;


//variables requises
// variables  et fonctions de app.c
extern Piece board[N][N] ;
extern Player current_player ;
extern gboolean try_move(int r0, int c0, int r1, int c1);

// Coupes possibles
extern gboolean highlight_moves[N][N];
extern void compute_possible_moves(int r0, int c0);



gboolean ai_enabled = FALSE ;
Player ai_player ;

static inline gboolean is_ai_ally(Piece p) { return ((p == RED_SOLDIER || p == RED_KING) && ai_player==RED)
     || ((p == BLUE_SOLDIER || p == BLUE_KING) && ai_player==BLUE); }


int ai_option_piece(){
    int count = 0 ;
    for(int i=0 ; i<N ; i++ ){
        for(int j=0 ; j<N ; j++ ){
            Piece p = board[i][j] ;
            if(is_ai_ally(p)){
                Position posi ;
                posi.r = i ;
                posi.c = j ;
                ai_pieces_jouables[count] = posi ;
                count++ ;
            }
        }
    }
    return count ;
}

int randint(int entierMax){ //je commence vraiment à en avoir besoin
    srand(time(NULL)) ;
    int result = rand() % entierMax ;
    return result ;
}

int ai_option_move(){
    int nombreDepiece = ai_option_piece() ;
    int numeroPiece = randint(nombreDepiece) ;
    Position p = ai_pieces_jouables[numeroPiece] ;
    int r0 = p.r ;
    int c0 = p.c ;
    compute_possible_moves(r0, c0) ;
    int count = 0 ;
    for(int i=0 ; i<N ; i++ ){
        for(int j=0 ; j<N ; j++ ){
           if (highlight_moves[i][j]){
                ai_posi_jouables[count].r = i ;
                ai_posi_jouables[count].c = j ;
                count++ ;
            }
        }
    }
    return count ;
}


gboolean ai_move(){
    int nombreDepiece = ai_option_piece() ;
    int numeroPiece = randint(nombreDepiece) ;
    Position p = ai_pieces_jouables[numeroPiece] ;
    int nombreDeMove = ai_option_move() ;
    int numeroMove = randint(nombreDeMove) ;
    Position to = ai_posi_jouables[numeroMove] ;
    Move move ;
    move.r0 = p.r ;
    move.c0 = p.c ;
    move.r1 = to.r ;
    move.c1 = to.c ;
    if (try_move(move.r0, move.c0, move.r1, move.c1)){
        current_player = (current_player==BLUE)?RED:BLUE;
        return TRUE ;
    }
    return FALSE ;
}



gboolean ai_gameloop(){
    gboolean fin = is_game_over() ;
    while(!fin){
        if(ai_enabled && current_player == ai_player){
            for(int k=0 ; k < N*N; k++ ){
                ai_posi_jouables->c = 0 ;
                ai_posi_jouables->r = 0 ;
            }
            for(int k=0 ; k < 20; k++ ){
                ai_pieces_jouables->c = 0 ;
                ai_pieces_jouables->r = 0 ;
            }
            ai_move();
            fin = is_game_over() ;
        }
    }
    return TRUE ;
}
