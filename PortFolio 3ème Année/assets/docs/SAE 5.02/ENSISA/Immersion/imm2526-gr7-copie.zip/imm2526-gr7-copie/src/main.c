#include "gui.h"
#include "app.h"
#include "../includes/network.h"
#include "../includes/header_commun.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// variables de app.c
extern Piece board[N][N] ;
extern Player current_player ;

int main(int argc, char **argv) {
    GtkApplication *app;
    const char *app_id = "dev.krojanty.game"; // ID par défaut

    if (argc < 2) {
        fprintf(stderr,
            "Usage:\n"
            "  %s -l\n"
            "  %s -s <port>\n"
            "  %s -c <ip:port>\n",
            argv[0], argv[0], argv[0]);
        return EXIT_FAILURE;
    }

    if (strcmp(argv[1], "-l") == 0) {
        // Mode local uniquement
        printf("[DEBUG][MAIN] Mode local activé\n");
        app_id = "dev.krojanty.game.local";
    } 
    else if (strcmp(argv[1], "-s") == 0) {
        // Mode serveur + GUI
        if (argc != 3) {
            fprintf(stderr, "Usage: %s -s <port>\n", argv[0]);
            return EXIT_FAILURE;
        }
        short port = atoi(argv[2]);
        printf("[DEBUG][MAIN] Mode serveur activé sur port %d\n", port);
        
        // Initialiser le serveur (non-bloquant)
        if (network_init_server(port) < 0) {
            fprintf(stderr, "Erreur: Impossible de démarrer le serveur\n");
            return EXIT_FAILURE;
        }
        
        app_id = "dev.krojanty.game.server";
    } 
    else if (strcmp(argv[1], "-c") == 0) {
        // Mode client + GUI
        if (argc != 3) {
            fprintf(stderr, "Usage: %s -c <ip:port>\n", argv[0]);
            return EXIT_FAILURE;
        }
        char *addr = strdup(argv[2]);
        char *colon = strchr(addr, ':');
        if (!colon) {
            fprintf(stderr, "Format attendu: <ip:port>\n");
            free(addr);
            return EXIT_FAILURE;
        }
        *colon = '\0';
        const char *ip = addr;
        short port = atoi(colon + 1);
        printf("[DEBUG][MAIN] Mode client activé vers %s:%d\n", ip, port);

        // Initialiser le client (non-bloquant)
        if (network_init_client(ip, port) < 0) {
            fprintf(stderr, "Erreur: Impossible de se connecter au serveur\n");
            free(addr);
            return EXIT_FAILURE;
        }
        
        free(addr);
        app_id = "dev.krojanty.game.client";
    }

    // Lancer GTK dans le thread principal
    printf("[DEBUG][MAIN] Lancement de l'application GTK avec ID: %s\n", app_id);
    app = gtk_application_new(app_id, G_APPLICATION_DEFAULT_FLAGS);
    g_signal_connect(app, "activate", G_CALLBACK(gui_activate), NULL);
    
    // Gérer la fermeture propre
    atexit(network_cleanup);
    
    int status = g_application_run(G_APPLICATION(app), 1, argv); // argc=1 pour éviter les arguments GTK
    g_object_unref(app);
    
    printf("[DEBUG][MAIN] Application terminée avec le statut: %d\n", status);
    return status;
}
