#ifndef HEADER_COMMUN_H
#define HEADER_COMMUN_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <stdint.h>
#include <gtk/gtk.h>
#include <math.h>
#include <cairo.h>
#include <cairo.h>
#include <unistd.h>         // close(), shutdown()

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>     // struct sockaddr_in, htons()
#include <netdb.h>          // getprotobyname()
#include <arpa/inet.h>      // htonl(), ntohl()

#endif //HEADER_COMMUN_H


// ajouter au début de chaque fichier : #include "../includes/header_commun.h"
