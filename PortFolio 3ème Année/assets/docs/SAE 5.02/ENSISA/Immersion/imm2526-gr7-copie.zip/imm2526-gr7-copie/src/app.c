#include "app.h"
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <gtk/gtk.h>

// Variables globales
Piece board[N][N];
Control control_grid[N][N];
Player current_player = BLUE;
int turn_count = 1;

int captured_blue_soldiers = 0;
int captured_red_soldiers = 0;
gboolean blue_king_alive = TRUE;
gboolean red_king_alive = TRUE;

gboolean has_selection = FALSE;
int sel_r = -1, sel_c = -1;
int hover_r = -1, hover_c = -1;

// Coups possibles
gboolean highlight_moves[N][N];

// Externe : label central
extern GtkWidget *turn_center_label;

// --------- Fonctions utilitaires ---------
static inline gboolean in_bounds(int r, int c) { return r >= 0 && r < N && c >= 0 && c < N; }
static inline gboolean is_city(int r, int c) { return (r == 0 && c == 0) || (r == N-1 && c == N-1); }
static inline gboolean is_blue_piece(Piece p) { return p == BLUE_SOLDIER || p == BLUE_KING; }
static inline gboolean is_red_piece(Piece p) { return p == RED_SOLDIER || p == RED_KING; }
static inline gboolean is_ally(Piece p, Player pl){ return (pl==BLUE)?is_blue_piece(p):is_red_piece(p); }
static inline gboolean is_enemy(Piece p, Player pl){ return (pl==BLUE)?is_red_piece(p):is_blue_piece(p); }
static inline gboolean is_king(Piece p){ return p == BLUE_KING || p == RED_KING; }

// --------- Calcul des coups possibles ---------
void compute_possible_moves(int r0, int c0) {
    memset(highlight_moves, 0, sizeof(highlight_moves));

    Piece p = board[r0][c0];
    if (p == EMPTY || !is_ally(p, current_player)) return;

    static const int dirs[4][2] = {{1,0},{-1,0},{0,1},{0,-1}};
    for (int k=0; k<4; k++) {
        int r = r0 + dirs[k][0];
        int c = c0 + dirs[k][1];
        while (in_bounds(r,c) && board[r][c] == EMPTY) {
            highlight_moves[r][c] = TRUE;
            r += dirs[k][0];
            c += dirs[k][1];
        }
    }
}

// --------- Comptages dynamiques ---------
static void compute_live_scores(int *blue_ctrl, int *red_ctrl, int *blue_soldiers, int *red_soldiers){
    int bc=0, rc=0, bs=0, rs=0;
    for(int r=0;r<N;r++){
        for(int c=0;c<N;c++){
            if(!is_city(r,c)){
                if(control_grid[r][c]==CTRL_BLUE) bc++;
                else if(control_grid[r][c]==CTRL_RED) rc++;
            }
            if(board[r][c]==BLUE_SOLDIER) bs++;
            else if(board[r][c]==RED_SOLDIER) rs++;
        }
    }
    if(blue_ctrl) *blue_ctrl = bc;
    if(red_ctrl) *red_ctrl = rc;
    if(blue_soldiers) *blue_soldiers = bs;
    if(red_soldiers) *red_soldiers = rs;
}

void update_labels(GtkWidget *blue_status_label, GtkWidget *blue_score_label, GtkWidget *blue_turn_label,
GtkWidget *red_status_label, GtkWidget *red_score_label, GtkWidget *red_turn_label){
    (void)blue_status_label; // Paramètre inutilisé
    (void)red_status_label;  // Paramètre inutilisé
    
    int bc, rc, bs, rs;
    compute_live_scores(&bc, &rc, &bs, &rs);

    char buf[512];

    // Score Bleu
    snprintf(buf, sizeof(buf),
        "<span size='18000' weight='bold' foreground='#1E90FF'>Contrôle: %d | Soldats: %d</span>", bc, bs);
    gtk_label_set_markup(GTK_LABEL(blue_score_label), buf);

    // Score Rouge
    snprintf(buf, sizeof(buf),
        "<span size='18000' weight='bold' foreground='#FF3030'>Contrôle: %d | Soldats: %d</span>", rc, rs);
    gtk_label_set_markup(GTK_LABEL(red_score_label), buf);

    // Label central "Au tour de ..."
    snprintf(buf, sizeof(buf),
        "<span size='22000' weight='bold' foreground='#FFD700'>Au tour de: %s</span>",
        current_player == BLUE ? "Bleu" : "Rouge");
    gtk_label_set_markup(GTK_LABEL(turn_center_label), buf);

    // Tour Bleu
    snprintf(buf, sizeof(buf),
        "<span size='16000' foreground='#1E90FF'>Tour %d / %d</span>", turn_count, MAX_TURNS);
    gtk_label_set_markup(GTK_LABEL(blue_turn_label), buf);

    // Tour Rouge
    snprintf(buf, sizeof(buf),
        "<span size='16000' foreground='#FF3030'>Tour %d / %d</span>", turn_count, MAX_TURNS);
    gtk_label_set_markup(GTK_LABEL(red_turn_label), buf);
}

// --------- Placement initial ---------
void new_game_setup(){
    memset(board, 0, sizeof(board));
    memset(control_grid, 0, sizeof(control_grid));
    memset(highlight_moves, 0, sizeof(highlight_moves));

    // Cités fixes
    board[0][0] = CITY; // A9
    board[8][8] = CITY; // I1
    
    // Contrôle des cités
    control_grid[0][0] = CTRL_BLUE; // A9 contrôlée par les bleus
    control_grid[8][8] = CTRL_RED;  // I1 contrôlée par les rouges

    // BLEU
    board[1][1] = BLUE_KING;
    board[0][2] = BLUE_SOLDIER;
    board[0][3] = BLUE_SOLDIER;
    board[1][2] = BLUE_SOLDIER;
    board[1][3] = BLUE_SOLDIER;
    board[2][0] = BLUE_SOLDIER;
    board[2][1] = BLUE_SOLDIER;
    board[2][2] = BLUE_SOLDIER;
    board[3][0] = BLUE_SOLDIER;
    board[3][1] = BLUE_SOLDIER;

    // ROUGE
    board[7][7] = RED_KING;
    board[5][7] = RED_SOLDIER;
    board[5][8] = RED_SOLDIER;
    board[6][6] = RED_SOLDIER;
    board[6][7] = RED_SOLDIER;
    board[6][8] = RED_SOLDIER;
    board[7][5] = RED_SOLDIER;
    board[7][6] = RED_SOLDIER;
    board[8][5] = RED_SOLDIER;
    board[8][6] = RED_SOLDIER;

    for(int r=0;r<N;r++){
        for(int c=0;c<N;c++){
            if(board[r][c]==BLUE_SOLDIER || board[r][c]==BLUE_KING)
                control_grid[r][c] = CTRL_BLUE;
            else if(board[r][c]==RED_SOLDIER || board[r][c]==RED_KING)
                control_grid[r][c] = CTRL_RED;
        }
    }

    current_player = BLUE;
    turn_count = 1;
    captured_blue_soldiers = 0;
    captured_red_soldiers = 0;
    blue_king_alive = TRUE;
    red_king_alive = TRUE;
    has_selection = FALSE; sel_r = sel_c = -1;
    hover_r = hover_c = -1;
}



// (les fonctions try_move, captures, popup de fin, etc. restent inchangées mais continuent d’appeler update_labels)

// --------- Gestion captures ---------
static gboolean path_clear(int r0,int c0,int r1,int c1){
    if(r0!=r1 && c0!=c1) return FALSE;
    int dr = (r1>r0) ? 1 : (r1<r0 ? -1 : 0);
    int dc = (c1>c0) ? 1 : (c1<c0 ? -1 : 0);
    int r = r0 + dr, c = c0 + dc;
    while(!(r==r1 && c==c1)){
        if(board[r][c]!=EMPTY) return FALSE;
        r += dr; c += dc;
    }
    return TRUE;
}

static void remove_piece(int r,int c){
    if(!in_bounds(r,c)) return;
    Piece p = board[r][c];
    if(p==EMPTY) return;

    if(p==BLUE_SOLDIER) captured_blue_soldiers++;
    else if(p==RED_SOLDIER) captured_red_soldiers++;
    else if(p==BLUE_KING) blue_king_alive = FALSE;
    else if(p==RED_KING) red_king_alive = FALSE;

    board[r][c] = EMPTY;
    if(!is_city(r,c)) control_grid[r][c] = CTRL_NEUTRAL;
}

static void try_linca_from(int r,int c, Player pl){
    static const int dirs[4][2] = {{1,0},{-1,0},{0,1},{0,-1}};
    for(int k=0;k<4;k++){
        int r1 = r + dirs[k][0];
        int c1 = c + dirs[k][1];
        int r2 = r1 + dirs[k][0];
        int c2 = c1 + dirs[k][1];
        if(!in_bounds(r1,c1)) continue;
        if(!in_bounds(r2,c2)) continue;
        Piece p1 = board[r1][c1];
        if(is_enemy(p1, pl)){
            Piece p2 = board[r2][c2];
            if(is_ally(p2, pl)){
                remove_piece(r1,c1);
            }
        }
    }
}

static void try_seultou(int dest_r,int dest_c,int dr,int dc, Player mover){
    if(dr==0 && dc==0) return;
    int r1 = dest_r + dr, c1 = dest_c + dc;
    if(!in_bounds(r1,c1)) return;
    Piece p1 = board[r1][c1];
    if(!is_enemy(p1, mover)) return;
    int r2 = r1 + dr, c2 = c1 + dc;
    gboolean supported = FALSE;
    if(in_bounds(r2,c2)){
        Piece behind = board[r2][c2];
        supported = is_ally(behind, (mover==BLUE)?RED:BLUE);
    }
    if(!supported){
        remove_piece(r1,c1);
    }
}

gboolean try_move(int r0,int c0,int r1,int c1){
    if(!in_bounds(r0,c0) || !in_bounds(r1,c1)) return FALSE;
    Piece p = board[r0][c0];
    if(p==EMPTY) return FALSE;
    if(!is_ally(p, current_player)) return FALSE;
    if(board[r1][c1]!=EMPTY) return FALSE;
    if(!path_clear(r0,c0,r1,c1)) return FALSE;

    board[r1][c1] = p;
    board[r0][c0] = EMPTY;

 // --- LOG du déplacement ---
    const char *player_str = (current_player == BLUE) ? "Bleu" : "Rouge";
    const char *piece_str  = (p == BLUE_KING || p == RED_KING) ? "Roi" : "Soldat";
    printf("[LOG] %s déplace %s de (%d,%d) vers (%d,%d)\n",
           player_str, piece_str, r0, c0, r1, c1);
    fflush(stdout);
 // ----------------------------
    if(!is_city(r1,c1)) control_grid[r1][c1] = (current_player==BLUE)?CTRL_BLUE:CTRL_RED;

    if(is_king(p)){
        if(current_player==BLUE && r1==N-1 && c1==N-1){
            red_king_alive = FALSE;
        }
        if(current_player==RED && r1==0 && c1==0){
            blue_king_alive = FALSE;
        }
    }

    try_linca_from(r1,c1,current_player);
    int dr = (r1>r0) ? 1 : (r1<r0 ? -1 : 0);
    int dc = (c1>c0) ? 1 : (c1<c0 ? -1 : 0);
    try_seultou(r1,c1,dr,dc,current_player);

    return TRUE;
}

// --------- Popup fin de partie ---------
void show_game_over_popup(const char *message, GtkWidget *parent) {
    // Convertir GtkRoot en GtkWidget si nécessaire
    GtkWidget *window_widget = GTK_WIDGET(parent);
    if (GTK_IS_ROOT(parent)) {
        window_widget = GTK_WIDGET(parent);
    }
    
    // Utiliser GtkAlertDialog pour GTK4 moderne
    GtkAlertDialog *dialog = gtk_alert_dialog_new("%s", message);
    gtk_alert_dialog_set_modal(dialog, TRUE);
    gtk_alert_dialog_set_detail(dialog, "Cliquez OK pour continuer.");
    
    // Afficher le dialogue
    gtk_alert_dialog_show(dialog, GTK_WINDOW(window_widget));
    
    // Libérer la référence
    g_object_unref(dialog);
}

// --------- Fin de partie ---------


gboolean is_game_over(){
    return !(red_king_alive && blue_king_alive) || (captured_blue_soldiers >= 8) || (captured_red_soldiers >= 8) || (turn_count > MAX_TURNS) ;
}
void check_end_and_update(GtkWidget *status_label, GtkWidget *drawing_area){
    if(!blue_king_alive){
        const char *msg = "Fin : Roi Bleu exécuté ou conquête Rouge — Rouge gagne !";
        gtk_label_set_text(GTK_LABEL(status_label), msg);
        gtk_widget_set_sensitive(drawing_area, FALSE);
        show_game_over_popup(msg, GTK_WIDGET(gtk_widget_get_root(drawing_area)));
        return;
    }

    if(!red_king_alive){
        const char *msg = "Fin : Roi Rouge exécuté ou conquête Bleue — Bleu gagne !";
        gtk_label_set_text(GTK_LABEL(status_label), msg);
        gtk_widget_set_sensitive(drawing_area, FALSE);
        show_game_over_popup(msg, GTK_WIDGET(gtk_widget_get_root(drawing_area)));
        return;
    }

    if(captured_red_soldiers >= 8){
        const char *msg = "Fin : 8 soldats rouges capturés — Bleu gagne !";
        gtk_label_set_text(GTK_LABEL(status_label), msg);
        gtk_widget_set_sensitive(drawing_area, FALSE);
        show_game_over_popup(msg, GTK_WIDGET(gtk_widget_get_root(drawing_area)));
        return;
    }

    if(captured_blue_soldiers >= 8){
        const char *msg = "Fin : 8 soldats bleus capturés — Rouge gagne !";
        gtk_label_set_text(GTK_LABEL(status_label), msg);
        gtk_widget_set_sensitive(drawing_area, FALSE);
        show_game_over_popup(msg, GTK_WIDGET(gtk_widget_get_root(drawing_area)));
        return;
    }

    if(turn_count > MAX_TURNS){
        int bc, rc, bs, rs;
        compute_live_scores(&bc,&rc,&bs,&rs);
        int blue_score = bc + bs;
        int red_score = rc + rs;

        char buf[256];
        if(blue_score > red_score)
            snprintf(buf,sizeof(buf),"Fin (64 tours). Score Bleu %d > Rouge %d — Bleu gagne !", blue_score, red_score);
        else if(red_score > blue_score)
            snprintf(buf,sizeof(buf),"Fin (64 tours). Score Rouge %d > Bleu %d — Rouge gagne !", red_score, blue_score);
        else
            snprintf(buf,sizeof(buf),"Fin (64 tours). Égalité %d - %d.", blue_score, red_score);

        gtk_label_set_text(GTK_LABEL(status_label), buf);
        gtk_widget_set_sensitive(drawing_area, FALSE);
        show_game_over_popup(buf, GTK_WIDGET(gtk_widget_get_root(drawing_area)));
        return;
    }
}