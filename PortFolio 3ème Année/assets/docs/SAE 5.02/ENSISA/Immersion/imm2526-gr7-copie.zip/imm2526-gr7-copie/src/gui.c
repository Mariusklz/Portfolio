#include "gui.h"
#include "app.h"
#include "ai.h"
#include "network.h"
#include <math.h>
#include <gtk/gtk.h>

#define WINDOWS_LONG 800
#define WINDOWS_HEIGHT 500
#define CELL_SIZE 52
#define GRID_SIZE 9
#define LINE_WIDTH 4
#define MARGIN 30

// Widgets globaux
GtkWidget *drawing_area;
GtkWidget *blue_score_label, *blue_turn_label;
GtkWidget *red_score_label, *red_turn_label;
GtkWidget *turn_center_label; // label centré

// Fonctions externes
extern Piece board[N][N];
extern Control control_grid[N][N];
extern Player current_player;
extern int turn_count;
extern gboolean has_selection;
extern int sel_r, sel_c;

extern gboolean try_move(int r0, int c0, int r1, int c1);
extern void new_game_setup();
extern void update_labels(GtkWidget *blue_status_label, GtkWidget *blue_score_label, GtkWidget *blue_turn_label,
                   GtkWidget *red_status_label, GtkWidget *red_score_label, GtkWidget *red_turn_label);
extern void check_end_and_update(GtkWidget *status_label, GtkWidget *drawing_area);

// Helpers locaux
static inline gboolean is_blue_piece(Piece p) { return p == BLUE_SOLDIER || p == BLUE_KING; }
static inline gboolean is_red_piece(Piece p) { return p == RED_SOLDIER || p == RED_KING; }

// Coupes possibles
extern gboolean highlight_moves[N][N];
extern void compute_possible_moves(int r0, int c0);

// Fonction pour vérifier les coups reçus via réseau
gboolean check_network_moves(gpointer user_data) {
    (void)user_data;
    
    int from_r, from_c, to_r, to_c;
    int result = network_check_move(&from_r, &from_c, &to_r, &to_c);
    
    if (result == 1) {
        // Coup reçu, l'appliquer
        printf("[DEBUG][GUI] Applying received move: (%d,%d) -> (%d,%d)\n", from_r, from_c, to_r, to_c);
        
        if (try_move(from_r, from_c, to_r, to_c)) {
            turn_count++;
            current_player = (current_player == BLUE) ? RED : BLUE;
            update_labels(NULL, blue_score_label, blue_turn_label, NULL, red_score_label, red_turn_label);
            check_end_and_update(NULL, drawing_area);
            gtk_widget_queue_draw(drawing_area);
        }
    }
    
    return TRUE; // Continuer le timer
}

// ----------- Dessin du plateau -----------
static void draw_grid(GtkDrawingArea *area, cairo_t *cr, int width, int height, gpointer user_data) {
    (void)area; (void)width; (void)height; (void)user_data;

    cairo_set_source_rgb(cr, 0.1, 0.1, 0.1);
    cairo_paint(cr);

    double offset_x = MARGIN;
    double offset_y = MARGIN;

    // Dessiner les indicateurs de position dans les marges
    cairo_set_source_rgb(cr, 1.0, 1.0, 1.0); // Blanc
    cairo_select_font_face(cr, "Sans", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_BOLD);
    cairo_set_font_size(cr, 14);
    
    // Lettres A-I en haut (dans la marge supérieure)
    for (int i = 0; i < GRID_SIZE; i++) {
        char letter[2] = {'A' + i, '\0'};
        cairo_text_extents_t extents;
        cairo_text_extents(cr, letter, &extents);
        
        double x = offset_x + i * CELL_SIZE + CELL_SIZE/2.0 - extents.width/2.0;
        double y = 18; // Dans la marge supérieure (MARGIN = 30)
        
        cairo_move_to(cr, x, y);
        cairo_show_text(cr, letter);
    }
    
    // Chiffres 9-1 à gauche (dans la marge gauche)
    for (int i = 0; i < GRID_SIZE; i++) {
        char number[2] = {'9' - i, '\0'};
        cairo_text_extents_t extents;
        cairo_text_extents(cr, number, &extents);
        
        double x = 15; // Dans la marge gauche (MARGIN = 30)
        double y = offset_y + i * CELL_SIZE + CELL_SIZE/2.0 + extents.height/2.0;
        
        cairo_move_to(cr, x, y);
        cairo_show_text(cr, number);
    }

    // Cases contrôlées
    for (int r = 0; r < N; r++) {
        for (int c = 0; c < N; c++) {
            if (control_grid[r][c] == CTRL_BLUE) {
                cairo_set_source_rgba(cr, 0.2, 0.4, 1.0, 0.25);
                cairo_rectangle(cr, offset_x + c*CELL_SIZE, offset_y + r*CELL_SIZE, CELL_SIZE, CELL_SIZE);
                cairo_fill(cr);
            } else if (control_grid[r][c] == CTRL_RED) {
                cairo_set_source_rgba(cr, 1.0, 0.2, 0.2, 0.25);
                cairo_rectangle(cr, offset_x + c*CELL_SIZE, offset_y + r*CELL_SIZE, CELL_SIZE, CELL_SIZE);
                cairo_fill(cr);
            }
        }
    }

    // Grille
    cairo_set_source_rgb(cr, 1.0, 1.0, 1.0);
    cairo_set_line_width(cr, LINE_WIDTH);
    for (int i = 0; i <= GRID_SIZE; i++) {
        cairo_move_to(cr, offset_x, offset_y + i * CELL_SIZE);
        cairo_line_to(cr, offset_x + GRID_SIZE * CELL_SIZE, offset_y + i * CELL_SIZE);
    }
    for (int j = 0; j <= GRID_SIZE; j++) {
        cairo_move_to(cr, offset_x + j * CELL_SIZE, offset_y);
        cairo_line_to(cr, offset_x + j * CELL_SIZE, offset_y + GRID_SIZE * CELL_SIZE);
    }
    cairo_stroke(cr);

    // Pièces
    for (int r = 0; r < N; r++) {
        for (int c = 0; c < N; c++) {
            Piece p = board[r][c];
            if (p == EMPTY) continue;

            double cx = offset_x + c * CELL_SIZE + CELL_SIZE/2.0;
            double cy = offset_y + r * CELL_SIZE + CELL_SIZE/2.0;
            double radius = CELL_SIZE / 2.8;

            if (p == CITY) {
                // Dessiner une cité avec un fond gris et un symbole
                cairo_set_source_rgb(cr, 0.5, 0.5, 0.5); // Gris foncé pour le fond
                cairo_arc(cr, cx, cy, radius, 0, 2 * M_PI);
                cairo_fill(cr);
                
                // Contour blanc
                cairo_set_source_rgb(cr, 1.0, 1.0, 1.0);
                cairo_set_line_width(cr, 2.0);
                cairo_arc(cr, cx, cy, radius - 2, 0, 2 * M_PI);
                cairo_stroke(cr);
                
                // Dessiner un carré au centre pour représenter la cité
                cairo_set_source_rgb(cr, 1.0, 1.0, 1.0); // Blanc
                double square_size = radius * 0.6;
                cairo_rectangle(cr, cx - square_size/2, cy - square_size/2, square_size, square_size);
                cairo_fill(cr);
                
                // Petite croix au centre
                cairo_set_source_rgb(cr, 0.5, 0.5, 0.5);
                cairo_set_line_width(cr, 2.0);
                cairo_move_to(cr, cx - square_size/4, cy);
                cairo_line_to(cr, cx + square_size/4, cy);
                cairo_move_to(cr, cx, cy - square_size/4);
                cairo_line_to(cr, cx, cy + square_size/4);
                cairo_stroke(cr);
            } else {
                // Dessiner les autres pièces (soldats et rois)
                if (p == BLUE_SOLDIER || p == BLUE_KING)
                    cairo_set_source_rgb(cr, 0.1, 0.3, 0.9);
                else
                    cairo_set_source_rgb(cr, 0.8, 0.1, 0.1);

                cairo_arc(cr, cx, cy, radius, 0, 2 * M_PI);
                cairo_fill(cr);

                if (p == BLUE_KING || p == RED_KING) {
                    cairo_set_source_rgb(cr, 1.0, 1.0, 1.0);
                    cairo_set_line_width(cr, 2.0);
                    cairo_arc(cr, cx, cy, radius - 3, 0, 2 * M_PI);
                    cairo_stroke(cr);
                }
            }
        }
    }
}

// ----------- Gestion clic -----------
static gboolean on_click(GtkGestureClick *gesture, int n_press, double x, double y, gpointer user_data) {

    (void)gesture; (void)n_press; (void)user_data;

    int col = (int)((x - MARGIN) / CELL_SIZE);
    int row = (int)((y - MARGIN) / CELL_SIZE);

    if (row >= 0 && row < N && col >= 0 && col < N) {
        if (has_selection) {
            if (try_move(sel_r, sel_c, row, col)) {
                // Coup valide, l'envoyer via réseau si connecté
                network_send_move_async(sel_r, sel_c, row, col);
                
                has_selection = FALSE;
                memset(highlight_moves, 0, sizeof(highlight_moves));
                turn_count++;
                current_player = (current_player==BLUE)?RED:BLUE;
                if(ai_enabled && current_player == ai_player){ //on passe la main à l'ia si c'est son tour
                    ai_move();
                }
            } else {
                has_selection = FALSE;
                memset(highlight_moves, 0, sizeof(highlight_moves));
            }
        } else {
            if (board[row][col] != EMPTY &&
                ((current_player==BLUE && is_blue_piece(board[row][col])) ||
                 (current_player==RED && is_red_piece(board[row][col])))) {
                has_selection = TRUE;
                sel_r = row;
                sel_c = col;
                compute_possible_moves(sel_r, sel_c);
            }
        }
        update_labels(NULL, blue_score_label, blue_turn_label, NULL, red_score_label, red_turn_label);
        check_end_and_update(NULL, drawing_area);
        gtk_widget_queue_draw(drawing_area);
    }
    return TRUE;
}

// ----------- Construction de l'interface -----------
void gui_activate(GtkApplication *app, gpointer user_data) {
    (void)user_data;
    GtkWidget *window = gtk_application_window_new(app);
    
    // Définir le titre selon le mode réseau
    const char *title = "Krojanty - Local";
    if (network_socket >= 0) {
        if (is_server) {
            title = "Krojanty - Serveur";
        } else {
            title = "Krojanty - Client";
        }
    }
    
    gtk_window_set_title(GTK_WINDOW(window), title);
    gtk_window_set_default_size(GTK_WINDOW(window), WINDOWS_LONG, WINDOWS_HEIGHT);
    gtk_window_set_resizable(GTK_WINDOW(window), FALSE);

    GtkWidget *root_box = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 10);
    gtk_window_set_child(GTK_WINDOW(window), root_box);

    // Infos joueur bleu
    GtkWidget *info_box_blue = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_box_set_spacing(GTK_BOX(info_box_blue), 20);
    gtk_widget_set_margin_start(info_box_blue, 20);

    GtkWidget *blue_title = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(blue_title),
        "<span size='20000' weight='bold' foreground='#1E90FF'>Joueur Bleu</span>");
    gtk_box_append(GTK_BOX(info_box_blue), blue_title);

    blue_score_label = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(blue_score_label),
        "<span size='16000' foreground='white'>Contrôle: 0 | Soldats: 0</span>");
    blue_turn_label = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(blue_turn_label),
        "<span size='16000' foreground='white'>Tour: 0</span>");

    gtk_box_append(GTK_BOX(info_box_blue), blue_score_label);
    gtk_box_append(GTK_BOX(info_box_blue), blue_turn_label);

    // Plateau + label centré
    GtkWidget *board_box = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);

    turn_center_label = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(turn_center_label),
        "<span size='22000' weight='bold' foreground='#FFD700'>Au tour de: Bleu</span>");
    gtk_widget_set_halign(turn_center_label, GTK_ALIGN_CENTER);
    gtk_box_append(GTK_BOX(board_box), turn_center_label);

    drawing_area = gtk_drawing_area_new();
    int total = CELL_SIZE * GRID_SIZE + MARGIN * 2;
    gtk_widget_set_size_request(drawing_area, total, total);
    gtk_drawing_area_set_draw_func(GTK_DRAWING_AREA(drawing_area), draw_grid, NULL, NULL);

    gtk_box_append(GTK_BOX(board_box), drawing_area);

    // Infos joueur rouge
    GtkWidget *info_box_red = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_box_set_spacing(GTK_BOX(info_box_red), 20);
    gtk_widget_set_margin_end(info_box_red, 20);

    GtkWidget *red_title = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(red_title),
        "<span size='20000' weight='bold' foreground='#FF3030'>Joueur Rouge</span>");
    gtk_box_append(GTK_BOX(info_box_red), red_title);

    red_score_label = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(red_score_label),
        "<span size='16000' foreground='white'>Contrôle: 0 | Soldats: 0</span>");
    red_turn_label = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(red_turn_label),
        "<span size='16000' foreground='white'>Tour: 0</span>");

    gtk_box_append(GTK_BOX(info_box_red), red_score_label);
    gtk_box_append(GTK_BOX(info_box_red), red_turn_label);

    // Ajout dans root_box
    gtk_box_append(GTK_BOX(root_box), info_box_blue);
    gtk_box_append(GTK_BOX(root_box), board_box);
    gtk_box_append(GTK_BOX(root_box), info_box_red);

    // Gestion clic
    GtkGesture *click = gtk_gesture_click_new();
    gtk_widget_add_controller(drawing_area, GTK_EVENT_CONTROLLER(click));
    g_signal_connect(click, "pressed", G_CALLBACK(on_click), NULL);

    // Timer pour vérifier les coups réseau (toutes les 100ms)
    g_timeout_add(100, check_network_moves, NULL);

    // Init partie
    new_game_setup();
    update_labels(NULL, blue_score_label, blue_turn_label, NULL, red_score_label, red_turn_label);

    gtk_window_present(GTK_WINDOW(window));
}
