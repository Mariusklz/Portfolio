//
// Created by Guillaume on 10/09/2025.
//

#ifndef SERVER_H
#define SERVER_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/socket.h>

typedef int SOCKET;
#define INVALID_SOCKET -1
#define SOCKET_ERROR -1

SOCKET TCP_Create_Server(short service);
int TCP_String_Reader(SOCKET s, char *input);
int TCP_Long_Writer(SOCKET s, long value);
void server_exchange(SOCKET s);

#endif
