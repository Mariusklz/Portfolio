//
// Created by Guillaume on 10/09/2025.
//

#include "client.h"

SOCKET TCP_Create_Client(char *serverName, short service) {
    struct protoent *ppe = getprotobyname("tcp");
    if (!ppe) exit(1);

    SOCKET s = socket(AF_INET, SOCK_STREAM, ppe->p_proto);
    if (s == INVALID_SOCKET) exit(1);

    struct sockaddr_in sin;
    memset(&sin, 0, sizeof(sin));
    sin.sin_family = AF_INET;
    sin.sin_addr.s_addr = inet_addr(serverName);
    sin.sin_port = htons(service);

    if (connect(s, (struct sockaddr*)&sin, sizeof(sin)) == SOCKET_ERROR) exit(1);
    return s;
}

int TCP_String_Writer(SOCKET s, char *output) {
    int bytes_sent = send(s, output, strlen(output), 0);
    if (bytes_sent == SOCKET_ERROR) exit(1);
    return bytes_sent;
}

int TCP_Long_Reader(SOCKET s, long *value) {
    char buffer[1500];
    int bytes_received = recv(s, buffer, sizeof(buffer), 0);
    if (bytes_received == SOCKET_ERROR) exit(1);
    buffer[bytes_received] = '\0';
    *value = ntohl(*(long*)buffer);
    return bytes_received;
}

void client_exchange() {
    SOCKET s = TCP_Create_Client("127.0.0.1", 1234);
    if (s == INVALID_SOCKET) exit(1);

    char *toSend = longToString(generate(1000));
    TCP_String_Writer(s, toSend);
    printf("Client sent : %s\n", toSend);

    shutdown(s, 1);

    long toReceive;
    TCP_Long_Reader(s, &toReceive);
    printf("Client received : %ld\n", toReceive);

    shutdown(s, 0);
}

// Fonctions utilitaires
long generate(long max) { return rand() % max; }
char* longToString(long value) { static char buffer[32]; sprintf(buffer, "%ld", value); return buffer; }
long stringToLong(char *str) { return atol(str); }

