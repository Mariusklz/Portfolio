document.addEventListener("DOMContentLoaded", () => {
    const ongletsContainer = document.getElementById("onglets");
    const accueilCasesContainer = document.getElementById("accueil-cases");
    const telCasesContainer = document.getElementById("tel-cases");

    const images = [
        { src: 'img/home.png', text: 'Accueil' },
        { src: 'img/phone.png', text: 'Listes' },
        { src: 'img/printer.png', text: 'Imprimante et scanners' },
        { src: 'img/ie.png', text: 'Liens Rapides' },
        { src: 'img/file.png', text: 'Documentation' },
        { src: 'img/share.png', text: 'Share' },
        { src: 'img/info.png', text: 'Info' }
    ];

    images.forEach((item, i) => {
        const onglet = document.createElement("button");
        onglet.classList.add("onglet");

        const img = document.createElement("img");
        img.src = item.src;
        img.alt = item.text;

        onglet.appendChild(img);
        ongletsContainer.appendChild(onglet);

        onglet.addEventListener("click", () => {
            document.querySelectorAll(".onglet").forEach(el => el.classList.remove("active"));
            onglet.classList.add("active");
            document.getElementById("dynamic-text").textContent = ` - ${item.text}`;

            if (item.text === "Accueil") {
                loadExcelData();
                accueilCasesContainer.style.display = "flex";
            } else {
                accueilCasesContainer.style.display = "none";
            }
        });

        if (i === 0) {
            onglet.classList.add("active");
            document.getElementById("dynamic-text").textContent = ` - ${item.text}`;
            loadExcelData();
            accueilCasesContainer.style.display = "flex";
        }
    });

    function loadExcelData() {
        accueilCasesContainer.innerHTML = ""; // Vide l'affichage pour éviter les doublons
        fetch('data/liens.xlsx')
            .then(response => response.arrayBuffer())
            .then(data => {
                const workbook = XLSX.read(data, { type: 'array' });
                const sheet = workbook.Sheets[workbook.SheetNames[0]];
                const jsonData = XLSX.utils.sheet_to_json(sheet);
                displayExcelData(jsonData);
            })
            .catch(error => console.error("Erreur lors du chargement du fichier Excel:", error));
    }

    function displayExcelData(data) {
        data.forEach(item => {
            const { Nom, Image, Lien } = item;

            const caseDiv = document.createElement("div");
            caseDiv.classList.add("accueil-case");

            const img = document.createElement("img");
            img.src = `img/${Image}`;
            img.alt = Nom;
            img.classList.add("case-image");

            caseDiv.appendChild(img);
            const name = document.createElement("p");
            name.textContent = Nom;
            caseDiv.appendChild(name);

            caseDiv.addEventListener("click", () => {
                window.location.href = Lien;
            });

            accueilCasesContainer.appendChild(caseDiv);
        });
    }
});
